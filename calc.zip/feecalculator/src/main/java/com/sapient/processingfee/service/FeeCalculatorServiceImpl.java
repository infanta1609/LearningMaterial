package com.sapient.processingfee.service;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.sapient.processingfee.dao.TransactionRepository;
import com.sapient.processingfee.dto.Transaction;

@Service
public class FeeCalculatorServiceImpl implements FeeCalculatorService {

	@Autowired
	TransactionRepository repository;
	
 	@Override
	public List<Transaction> getTranscationReport() {
 		return repository.findAllByGroup();
	}

	@Override
	public void readTransactionData() {
		Map<String, List<Transaction>> transcationMapData = readCSVFile();
		
		transcationMapData.keySet().forEach(key -> {
			List<Transaction> list = transcationMapData.get(key);
			list.forEach(trans -> {
				if(trans.isIntraTrans()) {
					saveTranscation(trans, 10.00);
				} else {
					normalTransactionFeeCalc(trans);
				}
			});
			
		});

	}
	
	private void normalTransactionFeeCalc(Transaction transcation) {
		if(transcation.getPriorityFlag()) {
			saveTranscation(transcation, 500.00);
		} else if(transcation.getTranscationType().equals("SELL")||transcation.getTranscationType().equals("WITHDRAW")) {
			saveTranscation(transcation,100.00);
		} else {
			saveTranscation(transcation,50.00);
		}
	}
	
	private void saveTranscation(Transaction trans, Double processingFee) {
		trans.setProcessingFee(processingFee);
		repository.save(trans);
		
	}


	private Map<String, List<Transaction>> readCSVFile(){
		Map<String, List<Transaction>> transMap = new HashMap<>();
		try {
			FileReader transcationDataReader = new FileReader(
					new File("C:\\Users\\Anthu\\Documents\\TranscationData.csv"));
			
			if (null != transcationDataReader) {
				CSVReader csvReader = new CSVReaderBuilder(transcationDataReader).withSkipLines(1).build();
				csvReader.forEach(nextRecord -> {
					String[] transcationDetails = nextRecord;
					Transaction transcation = null;
					if (transcationDetails.length == 7) {
						transcation = new Transaction(transcationDetails[0], transcationDetails[1],
								transcationDetails[2], transcationDetails[3], transcationDetails[4],
								Double.valueOf(transcationDetails[5]),
								(transcationDetails[6].equals("Y")) ? true : false, false);
						String key = transcationDetails[1]+"_"+transcationDetails[2]+"_"+transcationDetails[4];
						if(transMap.containsKey(key)) {
							List<Transaction> transcationData = transMap.get(key);
							
							for (Transaction tempTranscation : transcationData) {
								if(( transcationDetails[3].equals("SELL")&&tempTranscation.getTranscationType().equals("BUY")) ||
										( transcationDetails[3].equals("BUY")&&tempTranscation.getTranscationType().equals("SELL"))
										|| ( transcationDetails[3].equals("WITHDRAW")&&tempTranscation.getTranscationType().equals("DEPOSIT")) ||
										( transcationDetails[3].equals("DEPOSIT")&&tempTranscation.getTranscationType().equals("WITHDRAW"))) {
									if(!tempTranscation.isIntraTrans()) {
										tempTranscation.setIntraTrans(true);
										transcation.setIntraTrans(true);
										break;
									}
								}
							}
							transcationData.add(transcation);
							transMap.put(key, transcationData);
						} else {
							List<Transaction> transcationData = new ArrayList<>();
							transcationData.add(transcation);
							transMap.put(key, transcationData);
							
						}
					
					}
				});

			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return transMap;
	}

	@Override
	public List<Transaction> getAllTransaction() {
		return repository.findAll();
	}
 
}
