package com.sapient.processingfee.service;

import java.util.List;

import com.sapient.processingfee.dto.Transaction;

public interface FeeCalculatorService {
	
	void readTransactionData();
	
	List<Transaction> getTranscationReport();

	List<Transaction> getAllTransaction();

}
