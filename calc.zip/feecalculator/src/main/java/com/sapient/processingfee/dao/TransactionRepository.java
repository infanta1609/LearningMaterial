package com.sapient.processingfee.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sapient.processingfee.dto.Transaction;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, String> {

	@Query("SELECT  t.clientId, t.transcationType ,t.transcationDate , t.priorityFlag , "
			+ "sum(t.processingFee) FROM Transaction t GROUP BY  t.clientId, t.transcationType, t.transcationDate , "
			+ "t.priorityFlag ORDER BY t.clientId, t.transcationType, t.transcationDate , t.priorityFlag")
	List<Transaction> findAllByGroup();

}
