package com.sapient.processingfee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.sapient.processingfee.dao.TransactionRepository;
import com.sapient.processingfee.dto.Transaction;
import com.sapient.processingfee.service.FeeCalculatorService;

@SpringBootApplication
public class FeeCalculatorMain implements CommandLineRunner {

	@Autowired
	FeeCalculatorService feeCalculatorService;

	public static void main(String[] args) {
		SpringApplication.run(FeeCalculatorMain.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		System.out.println("########Success#############");
		feeCalculatorService.readTransactionData();

	}

}
