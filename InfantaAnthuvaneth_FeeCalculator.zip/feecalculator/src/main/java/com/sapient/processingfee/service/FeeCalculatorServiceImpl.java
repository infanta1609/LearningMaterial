package com.sapient.processingfee.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sapient.processingfee.commom.FeeCalcConstants;
import com.sapient.processingfee.dao.TransactionRepository;
import com.sapient.processingfee.dto.Transaction;
import com.sapient.processingfee.util.FeeCalculatorUtil;

@Service
public class FeeCalculatorServiceImpl implements FeeCalculatorService {

	@Autowired
	FeeCalculatorUtil feeCalculatorUtil;

	@Autowired
	TransactionRepository repository;

	@Override
	public List<Transaction> getTranscationReport() {
		return repository.findAllByGroup();
	}

	@Override
	public void readTransactionData() {
		Map<String, List<Transaction>> transcationMapData = feeCalculatorUtil.readCSVFile();

		transcationMapData.keySet().forEach(key -> {
			List<Transaction> transcationList = transcationMapData.get(key);
			transcationList.forEach(transcation -> {
				if (transcation.isIntraTrans()) {
					intraTransactionFeeCalc(transcation);
				} else {
					normalTransactionFeeCalc(transcation);
				}
			});

		});

	}

	private void normalTransactionFeeCalc(Transaction transcation) {
		if (FeeCalcConstants.PRIORITY_Y.equals(transcation.getPriorityFlag())) {
			transcation.setProcessingFee(FeeCalcConstants.PROCESSING_FEE_$500);
			saveTranscation(transcation);
		} else if (FeeCalcConstants.TRANSACTION_TYPE_SELL.equals(transcation.getTranscationType())
				|| FeeCalcConstants.TRANSACTION_TYPE_WITHDRAW.equals(transcation.getTranscationType())) {
			transcation.setProcessingFee(FeeCalcConstants.PROCESSING_FEE_$100);
			saveTranscation(transcation);
		} else {
			transcation.setProcessingFee(FeeCalcConstants.PROCESSING_FEE_$50);
			saveTranscation(transcation);
		}
	}
	
	private void intraTransactionFeeCalc(Transaction transcation) {
		transcation.setProcessingFee(FeeCalcConstants.PROCESSING_FEE_$10);
		saveTranscation(transcation);
	}

	private void saveTranscation(Transaction trans) {
		repository.save(trans);
	}

	@Override
	public List<Transaction> getAllTransaction() {
		return repository.findAll();
	}

}
