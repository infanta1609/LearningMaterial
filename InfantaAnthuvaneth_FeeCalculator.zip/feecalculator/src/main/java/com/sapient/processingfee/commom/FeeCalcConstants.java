package com.sapient.processingfee.commom;

public class FeeCalcConstants {
	
	public final static String TRANSACTION_TYPE_SELL = "SELL";
	public final static String TRANSACTION_TYPE_BUY = "BUY";
	public final static String TRANSACTION_TYPE_WITHDRAW = "WITHDRAW";
	public final static String TRANSACTION_TYPE_DEPOSIT = "DEPOSIT";
	
	public final static Double PROCESSING_FEE_$500 = 500.00;
	public final static Double PROCESSING_FEE_$100 = 100.00;
	public final static Double PROCESSING_FEE_$50 = 50.00;
	public final static Double PROCESSING_FEE_$10 = 10.00;
	
	public final static String PRIORITY_Y = "Y";
	public final static String PRIORITY_N = "N";
	

}
