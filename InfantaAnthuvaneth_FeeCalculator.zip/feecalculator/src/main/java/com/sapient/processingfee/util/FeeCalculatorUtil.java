package com.sapient.processingfee.util;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.sapient.processingfee.commom.FeeCalcConstants;
import com.sapient.processingfee.dto.Transaction;

@Component
public class FeeCalculatorUtil {

	public Map<String, List<Transaction>> readCSVFile() {
		Map<String, List<Transaction>> transactionMap = new HashMap<>();
		try {

			File file = ResourceUtils.getFile("classpath:TranscationData.csv");

			FileReader transcationDataReader = new FileReader(file);

			if (null != transcationDataReader) {
				CSVReader csvReader = new CSVReaderBuilder(transcationDataReader).withSkipLines(1).build();
				csvReader.forEach(nextRecord -> {
					String[] transcationRecord = nextRecord;
					Transaction transcation = null;
					if (transcationRecord.length == 7) {
						transcation = new Transaction(transcationRecord[0], transcationRecord[1], transcationRecord[2],
								transcationRecord[3], transcationRecord[4], Double.valueOf(transcationRecord[5]),
								transcationRecord[6], false);

						String key = transcationRecord[1] + "_" + transcationRecord[2] + "_" + transcationRecord[4];

						if (transactionMap.containsKey(key)) {
							List<Transaction> transactionDataList = transactionMap.get(key);
							for (Transaction existingTransaction : transactionDataList) {
								if (checkIntraTransactionData(existingTransaction.getTranscationType(),
										transcationRecord[3])) {
									if (!existingTransaction.isIntraTrans()) {
										existingTransaction.setIntraTrans(true);
										transcation.setIntraTrans(true);
										break;
									}
								}
							}
							transactionDataList.add(transcation);
							transactionMap.put(key, transactionDataList);
						} else {
							List<Transaction> transcationData = new ArrayList<>();
							transcationData.add(transcation);
							transactionMap.put(key, transcationData);

						}

					}
				});

			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		return transactionMap;
	}

	private boolean checkIntraTransactionData(String existingTransactionType, String currentTransactionType) {
		if ((FeeCalcConstants.TRANSACTION_TYPE_SELL.equals(currentTransactionType)
				&& FeeCalcConstants.TRANSACTION_TYPE_BUY.equals(existingTransactionType))
				|| (FeeCalcConstants.TRANSACTION_TYPE_BUY.equals(currentTransactionType)
						&& FeeCalcConstants.TRANSACTION_TYPE_SELL.equals(existingTransactionType))
				|| (FeeCalcConstants.TRANSACTION_TYPE_WITHDRAW.equals(currentTransactionType)
						&& FeeCalcConstants.TRANSACTION_TYPE_DEPOSIT.equals(existingTransactionType))
				|| (FeeCalcConstants.TRANSACTION_TYPE_DEPOSIT.equals(currentTransactionType)
						&& FeeCalcConstants.TRANSACTION_TYPE_WITHDRAW.equals(existingTransactionType))) {
			return true;
		} else {
			return false;
		}
	}

}
