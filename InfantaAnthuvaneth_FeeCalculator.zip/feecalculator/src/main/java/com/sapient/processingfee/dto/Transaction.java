package com.sapient.processingfee.dto;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Transaction {

	@Id
	private String transcationId;
	private String clientId;
	private String securityId;
	private String transcationType;
	private String transcationDate;
	private Double marketValue;
	private String priorityFlag;
	private Double processingFee;
	private boolean isIntraTrans;
	
	
	

	public Transaction() {
	}

	public Transaction(String transcationId, String clientId, String securityId, String transcationType,
			String transcationDate, Double marketValue, String priorityFlag, boolean isIntraTrans) {
		super();
		this.transcationId = transcationId;
		this.clientId = clientId;
		this.securityId = securityId;
		this.transcationType = transcationType;
		this.transcationDate = transcationDate;
		this.marketValue = marketValue;
		this.priorityFlag = priorityFlag;
		this.isIntraTrans = isIntraTrans;
	}

	public String getTranscationId() {
		return transcationId;
	}

	public void setTranscationId(String transcationId) {
		this.transcationId = transcationId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getSecurityId() {
		return securityId;
	}

	public void setSecurityId(String securityId) {
		this.securityId = securityId;
	}

	public String getTranscationType() {
		return transcationType;
	}

	public void setTranscationType(String transcationType) {
		this.transcationType = transcationType;
	}

	public String getTranscationDate() {
		return transcationDate;
	}

	public void setTranscationDate(String transcationDate) {
		this.transcationDate = transcationDate;
	}

	public Double getMarketValue() {
		return marketValue;
	}

	public void setMarketValue(Double marketValue) {
		this.marketValue = marketValue;
	}

	public String getPriorityFlag() {
		return priorityFlag;
	}

	public void setPriorityFlag(String priorityFlag) {
		this.priorityFlag = priorityFlag;
	}

	public Double getProcessingFee() {
		return processingFee;
	}

	public void setProcessingFee(Double processingFee) {
		this.processingFee = processingFee;
	}

	public boolean isIntraTrans() {
		return isIntraTrans;
	}

	public void setIntraTrans(boolean isIntraTrans) {
		this.isIntraTrans = isIntraTrans;
	}

	@Override
	public String toString() {
		return "Transcation [transcationId=" + transcationId + ", clientId=" + clientId + ", securityId=" + securityId
				+ ", transcationType=" + transcationType + ", transcationDate=" + transcationDate + ", marketValue="
				+ marketValue + ", priorityFlag=" + priorityFlag + "]";
	}

}
